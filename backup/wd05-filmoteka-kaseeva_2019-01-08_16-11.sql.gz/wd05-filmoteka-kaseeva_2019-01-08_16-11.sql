#SKD101|wd05-filmoteka-kaseeva|1|2019.01.08 16:11:57|13|13

DROP TABLE IF EXISTS `films`;
CREATE TABLE `films` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `genre` text NOT NULL,
  `year` int(11) NOT NULL,
  `description` text NOT NULL,
  `photo` char(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `films` VALUES