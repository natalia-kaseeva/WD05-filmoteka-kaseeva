#SKD101|wd05-filmoteka-kaseeva|1|2019.01.03 16:24:08|14|14

DROP TABLE IF EXISTS `films`;
CREATE TABLE `films` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `genre` text NOT NULL,
  `year` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `films` VALUES