#SKD101|wd05-filmoteka-kaseeva|2|2019.01.10 09:49:49|13|13

DROP TABLE IF EXISTS `films`;
CREATE TABLE `films` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `genre` text NOT NULL,
  `year` int(11) NOT NULL,
  `description` text NOT NULL,
  `photo` char(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `films` VALUES